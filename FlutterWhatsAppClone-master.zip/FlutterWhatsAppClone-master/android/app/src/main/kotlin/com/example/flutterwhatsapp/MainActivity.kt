package com.example.flutterwhatsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
