import 'package:flutter/material.dart';

class CallsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Center(
      child: new Text(
        "Calls",
        style: new TextStyle(fontSize: 20.0),
      ),
    );
  }
}
